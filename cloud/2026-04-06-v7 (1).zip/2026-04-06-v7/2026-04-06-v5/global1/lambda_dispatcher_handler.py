import json
import os
from typing import Iterable

import boto3


def _parse_site_ids(raw: str | None) -> list[str]:
    if not raw:
        return []
    parts = [p.strip() for p in raw.split(",")]
    return [p for p in parts if p]


def _event_site_ids(event: dict | None) -> list[str]:
    if not isinstance(event, dict):
        return []
    if isinstance(event.get("plant_ids"), list):
        return [str(p).strip() for p in event["plant_ids"] if str(p).strip()]
    single = event.get("plant_id") or event.get("site_id") or event.get("site_name")
    if isinstance(single, str) and single.strip():
        return [single.strip()]
    return []


def _iter_sites(event: dict | None) -> Iterable[str]:
    from_event = _event_site_ids(event)
    if from_event:
        return from_event
    return _parse_site_ids(os.getenv("SITE_IDS"))


def lambda_handler(event, context):
    target_function = os.getenv("TARGET_FUNCTION_NAME")
    if not target_function:
        return {
            "statusCode": 500,
            "body": json.dumps({"ok": False, "error": "TARGET_FUNCTION_NAME is required"}),
        }

    sites = list(_iter_sites(event))
    if not sites:
        return {
            "statusCode": 400,
            "body": json.dumps({"ok": False, "error": "No plant_id(s) provided"}),
        }

    lambda_client = boto3.client("lambda")
    invoked = []
    for site in sites:
        payload = json.dumps({"site_id": site, "plant_id": site, "site": site})
        lambda_client.invoke(
            FunctionName=target_function,
            InvocationType="Event",
            Payload=payload,
        )
        invoked.append(site)

    return {
        "statusCode": 200,
        "body": json.dumps({"ok": True, "invoked": invoked}),
    }

