from pathlib import Path
import pandas as pd

from utils.time_utils import timestamp_to_block

EPS_SMALL_WM2 = 50.0
MIN_COMBINED_INTENSITY = 0.12
MIN_GTI_THRESHOLD_RATIO = 0.15
DROP_THRESHOLD = 0.15
RISE_THRESHOLD = 0.15
CLOUD_INDEX_DELTA = 0.10

# =============================================================================
# WEATHER CSV LOADER (MINUTELY_15)
# =============================================================================
def load_weather_csv(path: Path) -> pd.DataFrame:
    """
    Load 15-minute weather CSV and normalize columns.
    Expected columns:
      date
      cloud_cover
      temperature_2m
      wind_speed_10m
      diffuse_radiation
      direct_normal_irradiance
      global_tilted_irradiance
    """
    if not path.exists():
        raise FileNotFoundError(f"Weather file not found: {path}")

    df = pd.read_csv(path)
    if "date" not in df.columns:
        raise ValueError("Weather CSV missing required 'date' column")

    df["date"] = pd.to_datetime(df["date"])
    return df


def fetch_weather_csv_for_date(
    target_date,
    out_path: Path,
    latitude: float = 24.56253056,
    longitude: float = 75.09140278
) -> Path:
    """
    Fetch 15-minute weather data for a date using Open-Meteo and write CSV.
    Requires: openmeteo_requests, retry_requests, requests.
    """
    try:
        import openmeteo_requests
        from retry_requests import retry
        import requests
    except Exception as exc:
        raise RuntimeError(
            "Missing weather dependencies. Install openmeteo_requests and retry_requests."
        ) from exc

    base_session = requests.Session()
    retry_session = retry(base_session, retries=5, backoff_factor=0.2)
    openmeteo = openmeteo_requests.Client(session=retry_session)

    date_str = (
        target_date.strftime("%Y-%m-%d")
        if hasattr(target_date, "strftime")
        else str(target_date)
    )

    url = "https://historical-forecast-api.open-meteo.com/v1/forecast"
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "start_date": date_str,
        "end_date": date_str,
        "minutely_15": [
            "cloud_cover",
            "temperature_2m",
            "wind_speed_10m",
            "diffuse_radiation",
            "direct_normal_irradiance",
            "global_tilted_irradiance",
        ],
        "timezone": "auto",
    }

    responses = openmeteo.weather_api(url, params=params)
    response = responses[0]

    minutely_15 = response.Minutely15()
    cloud_cover = minutely_15.Variables(0).ValuesAsNumpy()
    temperature_2m = minutely_15.Variables(1).ValuesAsNumpy()
    wind_speed_10m = minutely_15.Variables(2).ValuesAsNumpy()
    diffuse_radiation = minutely_15.Variables(3).ValuesAsNumpy()
    direct_normal_irradiance = minutely_15.Variables(4).ValuesAsNumpy()
    global_tilted_irradiance = minutely_15.Variables(5).ValuesAsNumpy()

    minutely_15_data = {
        "date": pd.date_range(
            start=pd.to_datetime(
                minutely_15.Time() + response.UtcOffsetSeconds(), unit="s", utc=True
            ),
            end=pd.to_datetime(
                minutely_15.TimeEnd() + response.UtcOffsetSeconds(), unit="s", utc=True
            ),
            freq=pd.Timedelta(seconds=minutely_15.Interval()),
            inclusive="left",
        )
    }
    minutely_15_data["cloud_cover"] = cloud_cover
    minutely_15_data["temperature_2m"] = temperature_2m
    minutely_15_data["wind_speed_10m"] = wind_speed_10m
    minutely_15_data["diffuse_radiation"] = diffuse_radiation
    minutely_15_data["direct_normal_irradiance"] = direct_normal_irradiance
    minutely_15_data["global_tilted_irradiance"] = global_tilted_irradiance

    df = pd.DataFrame(data=minutely_15_data)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_path, index=False)
    return out_path


def build_weather_by_block(weather_df: pd.DataFrame) -> dict:
    """
    Build a block-indexed weather map from 15-minute weather data.
    """
    weather_by_block = {}
    for _, row in weather_df.iterrows():
        block = timestamp_to_block(row["date"])
        weather_by_block[block] = {
            "temperature_2m": float(row["temperature_2m"]),
            "wind_speed_10m": float(row["wind_speed_10m"]),
            "diffuse_radiation": float(row["diffuse_radiation"]),
            "direct_normal_irradiance": float(row.get("direct_normal_irradiance", 0.0)),
            "global_tilted_irradiance": float(row["global_tilted_irradiance"]),
        }
    return weather_by_block


def classify_block_weather_state(
    block: int,
    weather_by_block: dict,
    current_now: dict | None = None,
    current_prev: dict | None = None,
    max_block: int = 80,
    eps_small: float = EPS_SMALL_WM2,
    max_gti_today: float = 1.0,
    return_details: bool = False,
) -> str:
    """
    Abrupt weather detection using forward-looking horizon (T+3..T+5).
    Returns "ABRUPT"/"NORMAL" by default, or details when return_details=True.
    """
    details = {
        "state": "NORMAL",
        "abrupt_type": None,
        "cloud_dev": 0.0,
        "shift_ratio": 0.0,
        "cloud_threshold": 0.0,
        "shift_threshold": 0.0,
    }

    w_now = weather_by_block.get(block, {})
    gti_t = w_now.get("global_tilted_irradiance")
    min_gti_valid = MIN_GTI_THRESHOLD_RATIO * max(max_gti_today, 1.0)
    if gti_t is None or gti_t < min_gti_valid:
        return details if return_details else details["state"]

    w_t3 = weather_by_block.get(block + 3, {})
    w_t4 = weather_by_block.get(block + 4, {})
    w_t5 = weather_by_block.get(block + 5, {})

    dhi_t = w_now.get("diffuse_radiation")
    gti_t3 = w_t3.get("global_tilted_irradiance")
    gti_t4 = w_t4.get("global_tilted_irradiance")
    gti_t5 = w_t5.get("global_tilted_irradiance")
    dhi_t3 = w_t3.get("diffuse_radiation")
    dhi_t4 = w_t4.get("diffuse_radiation")
    dhi_t5 = w_t5.get("diffuse_radiation")

    if (
        gti_t3 is None
        or gti_t4 is None
        or gti_t5 is None
        or dhi_t is None
        or dhi_t3 is None
        or dhi_t4 is None
        or dhi_t5 is None
    ):
        return details if return_details else details["state"]

    mean_future = (gti_t3 + gti_t4 + gti_t5) / 3.0
    gti_change = (mean_future - gti_t) / max(gti_t, 1.0)

    if gti_change <= -DROP_THRESHOLD:
        candidate_type = "DECREASE"
    elif gti_change >= RISE_THRESHOLD:
        candidate_type = "INCREASE"
    else:
        return details if return_details else details["state"]

    if candidate_type == "DECREASE":
        if not (gti_t3 <= gti_t and gti_t4 <= gti_t3 and gti_t5 <= gti_t4):
            return details if return_details else details["state"]
    else:
        if not (gti_t3 >= gti_t and gti_t4 >= gti_t3 and gti_t5 >= gti_t4):
            return details if return_details else details["state"]

    cloud_t = dhi_t / max(gti_t, 1.0)
    cloud_t3 = dhi_t3 / max(gti_t3, 1.0)
    cloud_t4 = dhi_t4 / max(gti_t4, 1.0)
    cloud_t5 = dhi_t5 / max(gti_t5, 1.0)
    cloud_future = (cloud_t3 + cloud_t4 + cloud_t5) / 3.0
    cloud_delta = cloud_future - cloud_t

    if candidate_type == "DECREASE" and cloud_delta < CLOUD_INDEX_DELTA:
        return details if return_details else details["state"]
    if candidate_type == "INCREASE" and cloud_delta > -CLOUD_INDEX_DELTA:
        return details if return_details else details["state"]

    details["state"] = "ABRUPT"
    details["abrupt_type"] = candidate_type
    details["cloud_dev"] = float(cloud_delta)
    details["shift_ratio"] = float(gti_change)
    confidence = (0.7 * abs(gti_change)) + (0.3 * abs(cloud_delta))
    details["combined_intensity"] = float(confidence)

    return details if return_details else details["state"]
