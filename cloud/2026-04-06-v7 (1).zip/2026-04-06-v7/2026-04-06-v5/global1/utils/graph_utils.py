﻿from pathlib import Path
import os

import pandas as pd

from utils.site_config_loader import load_site_config
from utils.time_utils import timestamp_to_block

DEFAULT_PLANT_CAPACITY_MW = 5.10
DEFAULT_PENALTY_BAND_PCT = 0.10


def _normalize_penalty_band_fraction(raw_pct: float) -> float:
    # Accept both fraction (0.10 => 10%) and whole-percent (10 => 10%).
    return raw_pct / 100.0 if raw_pct > 1.0 else raw_pct


def _resolve_band_mw() -> float:
    """
    Resolve per-site tolerance band in MW.
    Priority:
      1) penalty_band_mw
      2) plant_capacity_mw * penalty_band_pct
    """
    site_id = os.getenv("SITE_ID", "SIRMOUR").strip().upper()
    try:
        cfg = load_site_config(site_id)
    except Exception:
        return float(DEFAULT_PLANT_CAPACITY_MW) * float(DEFAULT_PENALTY_BAND_PCT)

    band_mw = cfg.get("penalty_band_mw")
    if band_mw is not None:
        return float(band_mw)

    plant_capacity = float(cfg.get("plant_capacity_mw", DEFAULT_PLANT_CAPACITY_MW))
    penalty_band_pct_raw = float(cfg.get("penalty_band_pct", DEFAULT_PENALTY_BAND_PCT))
    penalty_band_frac = _normalize_penalty_band_fraction(penalty_band_pct_raw)
    return plant_capacity * penalty_band_frac


def _resolve_plant_label() -> str:
    site_id = os.getenv("SITE_ID", "SIRMOUR").strip().upper()
    try:
        cfg = load_site_config(site_id)
        return str(cfg.get("site_id", site_id)).strip().upper() or site_id
    except Exception:
        return site_id


def _resolve_custom_input_dir(schedule_csv: Path) -> Path | None:
    """
    Try to map custom/output/<SITE>/<DATE>/... to custom/input/<SITE>/<DATE>/...
    """
    parts = list(schedule_csv.parts)
    try:
        output_idx = parts.index("custom")
    except ValueError:
        return None
    if output_idx + 2 >= len(parts) or parts[output_idx + 1] != "output":
        return None
    parts[output_idx + 1] = "input"
    return Path(*parts[: output_idx + 4])


def _load_vedanjay_schedule(schedule_csv: Path) -> pd.DataFrame | None:
    """
    Load Vedanjay team schedule for graphing.
    Expected CSV with a column named 'Schedule'.
    Optional columns:
      - block (preferred)
      - TIME / timestamp / date (will be converted to block)
    If no block/time column, will assign blocks by row order (1..96).
    """
    env_path = os.getenv("VEDANJAY_SCHEDULE_PATH")
    candidates: list[Path] = []
    if env_path:
        candidates.append(Path(env_path))

    input_dir = _resolve_custom_input_dir(schedule_csv)
    if input_dir is not None:
        for dir_name in ("vedanjay_schedule", "Vedanjay_Schedule"):
            ved_dir = input_dir / dir_name
            if ved_dir.exists():
                candidates.extend(sorted(ved_dir.glob("*.csv")))

    for path in candidates:
        if not path.exists():
            continue
        try:
            # Detect header row that contains "Block" and "Schedule"
            header_row_idx = None
            with path.open("r", encoding="utf-8", errors="ignore") as fh:
                for idx, line in enumerate(fh):
                    if "Block" in line and "Schedule" in line:
                        header_row_idx = idx
                        break
                    if idx > 50:
                        break
            if header_row_idx is not None:
                df = pd.read_csv(path, skiprows=header_row_idx)
            else:
                df = pd.read_csv(path)
        except Exception:
            continue
        if "Schedule" not in df.columns:
            continue

        block_col = None
        for col in ("block", "Block", "BLOCK"):
            if col in df.columns:
                block_col = col
                break
        if block_col:
            out = df[[block_col, "Schedule"]].rename(columns={block_col: "block"})
            return out

        time_col = None
        for col in ("TIME", "timestamp", "Timestamp", "date", "Date"):
            if col in df.columns:
                time_col = col
                break
        if time_col:
            tmp = df[[time_col, "Schedule"]].copy()
            tmp[time_col] = pd.to_datetime(tmp[time_col], errors="coerce")
            tmp["block"] = tmp[time_col].apply(lambda x: timestamp_to_block(x) if pd.notna(x) else None)
            return tmp[["block", "Schedule"]].dropna(subset=["block"])

        tmp = df[["Schedule"]].copy()
        tmp["block"] = range(1, len(tmp) + 1)
        return tmp[["block", "Schedule"]]

    return None


def generate_schedule_graph(
    schedule_csv: Path,
    intraday_df: pd.DataFrame,
    metered_by_block: pd.Series,
    current_block: int,
    output_dir: Path,
):
    """
    Create a line graph with:
      - Generated schedule
      - Metered data for all available blocks
      - Intraday forecast (all blocks)
      - Tolerance bands around algo schedule and intraday forecast
    Saves an interactive HTML file under output_dir/graphs/.
    """
    try:
        import plotly.graph_objects as go
    except Exception:
        # Plotly not installed; skip graph generation
        return

    sched_df = pd.read_csv(schedule_csv)

    # Show metered data for all blocks where meter values exist for the day.
    # Schedule logic still uses engine/current block limits; this affects graphing only.
    metered_series = sched_df["block"].map(metered_by_block)

    # Tolerable bounds:
    # 1) Algo schedule +/- band
    # 2) Intraday forecast +/- band
    band_mw = _resolve_band_mw()
    algo_series = sched_df["algo_schedule_mw"].astype(float)
    algo_max_tolerable = algo_series + band_mw
    algo_min_tolerable = algo_series - band_mw

    intraday_series = sched_df["block"].map(intraday_df.set_index("block")["forecast_mw"]).astype(float)
    intraday_max_tolerable = intraday_series + band_mw
    intraday_min_tolerable = intraday_series - band_mw

    # Title timestamp from schedule for the current block (12-hour format)
    title_suffix = f"Block {current_block}"
    if "timestamp" in sched_df.columns:
        ts_row = sched_df.loc[sched_df["block"] == current_block, "timestamp"]
        if not ts_row.empty and pd.notna(ts_row.iloc[0]):
            ts = pd.to_datetime(ts_row.iloc[0])
            date_str = ts.strftime("%b %d, %Y")
            time_str = ts.strftime("%I:%M %p").lstrip("0")
            title_suffix = f"{date_str} {time_str}"

    fig = go.Figure()

    fig.add_trace(
        go.Scatter(
            x=sched_df["block"],
            y=sched_df["algo_schedule_mw"],
            mode="lines+markers",
            name="Generated Schedule",
            line=dict(width=2.5, color="#1f77b4"),
        )
    )

    fig.add_trace(
        go.Scatter(
            x=sched_df["block"],
            y=metered_series,
            mode="lines+markers",
            name="Metered (Actual available)",
            line=dict(width=2.0, color="#000000"),
        )
    )

    fig.add_trace(
        go.Scatter(
            x=intraday_df["block"],
            y=intraday_df["forecast_mw"],
            mode="lines+markers",
            name="Enercast Intraday Forecast",
            line=dict(width=2.0, color="#ff7f0e"),
        )
    )

    ved_df = _load_vedanjay_schedule(schedule_csv)
    if ved_df is not None and not ved_df.empty:
        fig.add_trace(
            go.Scatter(
                x=ved_df["block"],
                y=ved_df["Schedule"],
                mode="lines+markers",
                name="Vedanjay Team Schedule",
                line=dict(width=2.0, color="#9467bd"),
            )
        )

    if "BaseForecast" in sched_df.columns:
        fig.add_trace(
            go.Scatter(
                x=sched_df["block"],
                y=sched_df["BaseForecast"],
                mode="lines+markers",
                name="Base Forecast (Raw)",
                line=dict(width=2.0, color="#2ca02c"),
            )
        )

    if "EffectiveBaseForecast" in sched_df.columns and "BaseForecast" in sched_df.columns:
        # Show only when curtailment/shutdown changed base values.
        eff_diff = (
            sched_df["EffectiveBaseForecast"].astype(float)
            - sched_df["BaseForecast"].astype(float)
        ).abs()
        should_plot_effective = bool((eff_diff > 1e-6).any())
    else:
        should_plot_effective = False

    if should_plot_effective:
        fig.add_trace(
            go.Scatter(
                x=sched_df["block"],
                y=sched_df["EffectiveBaseForecast"],
                mode="lines+markers",
                name="Base Forecast (Curtailment Applied)",
                line=dict(width=2.2, color="#d62728"),
            )
        )

    fig.add_trace(
        go.Scatter(
            x=sched_df["block"],
            y=algo_max_tolerable,
            mode="lines",
            name="Max Tolerable (Algo +/- Band)",
            line=dict(width=1.2, dash="dot", color="#7f7f7f"),
        )
    )

    fig.add_trace(
        go.Scatter(
            x=sched_df["block"],
            y=algo_min_tolerable,
            mode="lines",
            name="Min Tolerable (Algo +/- Band)",
            line=dict(width=1.2, dash="dot", color="#7f7f7f"),
        )
    )

    fig.add_trace(
        go.Scatter(
            x=sched_df["block"],
            y=intraday_max_tolerable,
            mode="lines",
            name="Max Tolerable (Intraday +/- Band)",
            line=dict(width=1.0, dash="dot", color="#8B4513"),
        )
    )

    fig.add_trace(
        go.Scatter(
            x=sched_df["block"],
            y=intraday_min_tolerable,
            mode="lines",
            name="Min Tolerable (Intraday +/- Band)",
            line=dict(width=1.0, dash="dot", color="#8B4513"),
        )
    )

    out_of_range = (
        (sched_df["algo_schedule_mw"] > intraday_max_tolerable)
        | (sched_df["algo_schedule_mw"] < intraday_min_tolerable)
    ) & intraday_max_tolerable.notna() & intraday_min_tolerable.notna()

    if out_of_range.any():
        fig.add_trace(
            go.Scatter(
                x=sched_df.loc[out_of_range, "block"],
                y=sched_df.loc[out_of_range, "algo_schedule_mw"],
                mode="markers",
                name="Out of Tolerance",
                marker=dict(symbol="x", size=10, color="#d62728"),
            )
        )

    plant_label = _resolve_plant_label()
    fig.update_layout(
        title=dict(
            text=f"<b>{plant_label}</b> | Schedule vs Metered vs Intraday ({title_suffix})",
            x=0.01,
            xanchor="left",
        ),
        xaxis_title="Block",
        yaxis_title="Power (MW)",
        hovermode="x unified",
        xaxis=dict(tickmode="linear", dtick=1),
        margin=dict(t=95),
    )
    fig.add_vline(
        x=current_block,
        line_width=2,
        line_dash="dash",
        line_color="#8c564b",
        annotation_text=f"Meter cutoff & schedule block {current_block}",
        annotation_position="top left",
    )

    current_sched = sched_df.loc[sched_df["block"] == current_block, "algo_schedule_mw"]
    if not current_sched.empty and pd.notna(current_sched.iloc[0]):
        fig.add_trace(
            go.Scatter(
                x=[current_block],
                y=[float(current_sched.iloc[0])],
                mode="markers",
                name="Schedule Start Block",
                marker=dict(symbol="diamond", size=12, color="#8c564b"),
            )
        )

    graphs_dir = output_dir / "graphs"
    graphs_dir.mkdir(parents=True, exist_ok=True)
    out_html = graphs_dir / f"schedule_{current_block:02d}.html"
    fig.write_html(out_html, include_plotlyjs="cdn")
