import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import boto3


BUCKET = os.environ["BUCKET"]
PLANT_ID_BASE = os.environ.get("PLANT_ID", "vedanjay")
SITE_NAME = os.environ.get("SITE_NAME", "GSNP")
WORK_ROOT_BASE = Path("/tmp")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

s3 = boto3.client("s3")


WORK_ROOT = WORK_ROOT_BASE / "work"
RAW_BASE_PREFIX = f"raw/{PLANT_ID_BASE}/{SITE_NAME}"


def _configure_for_site(site_name: str) -> None:
    global SITE_NAME, WORK_ROOT, RAW_BASE_PREFIX
    SITE_NAME = site_name
    WORK_ROOT = WORK_ROOT_BASE / f"work_{site_name.lower()}"
    RAW_BASE_PREFIX = f"raw/{PLANT_ID_BASE}/{SITE_NAME}"


def _reset_workdir() -> None:
    if WORK_ROOT.exists():
        shutil.rmtree(WORK_ROOT)
    WORK_ROOT.mkdir(parents=True, exist_ok=True)
    (WORK_ROOT / "data").mkdir(parents=True, exist_ok=True)


def _prepare_fetch_assets() -> None:
    src = Path("/var/task") / "Data loader"
    dst = WORK_ROOT / "Data loader"
    if not src.exists():
        raise FileNotFoundError(f"Missing source folder: {src}")
    shutil.copytree(src, dst)


def _run_fetch_once(site_name: str) -> subprocess.CompletedProcess:
    script = WORK_ROOT / "Data loader" / "Fetchdata.py"
    if not script.exists():
        raise FileNotFoundError(f"Missing fetch script: {script}")

    env = dict(os.environ)
    env["RUN_ONCE"] = "1"
    env["PYTHONPATH"] = "/var/task"
    env["SITE_ID"] = site_name
    env["SITE_NAME"] = site_name

    return subprocess.run(
        [sys.executable, str(script)],
        cwd=str(WORK_ROOT),
        env=env,
        capture_output=True,
        text=True,
    )


def _candidate_data_roots() -> list[Path]:
    candidates = [
        WORK_ROOT / "data",
        WORK_ROOT / "Data loader" / "data",
        WORK_ROOT / "Data loader" / "..\\data",
        WORK_ROOT / "Data loader" / "../data",
    ]
    out = []
    for c in candidates:
        try:
            if c.exists() and c.is_dir():
                out.append(c.resolve())
        except Exception:
            pass

    uniq = []
    seen = set()
    for p in out:
        s = str(p)
        if s not in seen:
            uniq.append(p)
            seen.add(s)
    return uniq



def _upload_raw_data() -> int:
    roots = _candidate_data_roots()
    if not roots:
        return 0

    uploaded = 0
    site_token = (SITE_NAME or "").strip().upper()
    for data_root in roots:
        for f in data_root.rglob("*"):
            if not f.is_file():
                continue

            rel = f.relative_to(data_root)
            parts = rel.parts

            date_part = None
            suffix = ""
            if parts and DATE_RE.match(parts[0]):
                # date/... (preferred)
                date_part = parts[0]
                suffix = "/".join(parts[1:]) if len(parts) > 1 else ""
            elif (
                len(parts) >= 2
                and parts[0].strip().upper() == site_token
                and DATE_RE.match(parts[1])
            ):
                # SITE/DATE/...
                date_part = parts[1]
                suffix = "/".join(parts[2:]) if len(parts) > 2 else ""
            elif (
                len(parts) >= 3
                and parts[0] == "_shared"
                and parts[1].strip().upper() == site_token
                and DATE_RE.match(parts[2])
            ):
                # _shared/SITE/DATE/...
                date_part = parts[2]
                suffix = "/".join(parts[3:]) if len(parts) > 3 else ""
            elif (
                len(parts) >= 3
                and parts[0].strip().upper() == site_token
                and parts[1] == "_shared"
                and DATE_RE.match(parts[2])
            ):
                # SITE/_shared/DATE/...
                date_part = parts[2]
                suffix = "/".join(parts[3:]) if len(parts) > 3 else ""

            if date_part:
                # Always normalize into primary layout
                key = f"{RAW_BASE_PREFIX}/{date_part}/{suffix}" if suffix else f"{RAW_BASE_PREFIX}/{date_part}"
            else:
                # Non-date assets go to shared area
                key = f"{RAW_BASE_PREFIX}/_shared/{rel.as_posix()}"

            s3.upload_file(str(f), BUCKET, key)
            uploaded += 1

    return uploaded


def _parse_site_ids(raw: str | None) -> list[str]:
    if not raw:
        return []
    parts = [p.strip() for p in raw.split(",")]
    return [p for p in parts if p]


def _resolve_site_names(event: dict | None) -> list[str]:
    if isinstance(event, dict):
        if isinstance(event.get("plant_ids"), list):
            return [str(p).strip() for p in event["plant_ids"] if str(p).strip()]
        single = event.get("plant_id") or event.get("site_id") or event.get("site_name")
        if isinstance(single, str) and single.strip():
            return [single.strip()]
    env_sites = _parse_site_ids(os.environ.get("SITE_IDS"))
    if env_sites:
        return env_sites
    fallback = os.environ.get("SITE_NAME", SITE_NAME)
    return [fallback] if fallback else []



def lambda_handler(event, context):
    try:
        sites = _resolve_site_names(event)
        if not sites:
            return {
                "statusCode": 400,
                "body": json.dumps({"ok": False, "error": "No site_ids provided"}),
            }

        results = []
        overall_ok = True

        for site in sites:
            _configure_for_site(site)
            _reset_workdir()
            _prepare_fetch_assets()
            proc = _run_fetch_once(site)

            uploaded = 0
            if proc.returncode == 0:
                uploaded = _upload_raw_data()
            else:
                overall_ok = False

            results.append({
                "site": site,
                "ok": proc.returncode == 0,
                "returncode": proc.returncode,
                "uploaded_files": uploaded,
                "stdout_tail": proc.stdout[-4000:],
                "stderr_tail": proc.stderr[-4000:],
            })

        return {
            "statusCode": 200 if overall_ok else 500,
            "body": json.dumps({"ok": overall_ok, "results": results}),
        }
    except Exception as exc:
        return {
            "statusCode": 500,
            "body": json.dumps({"ok": False, "error": str(exc)}),
        }
